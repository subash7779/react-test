import React, { useState } from "react";

import "bootstrap/dist/css/bootstrap.min.css";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

import { USERLIST } from "./constants";
import ProfileCard from "./ProfileCard";

function App() {
  const [users, setUsers] = useState(USERLIST);

  const deleteUser = (id) => {
    let newSet = [...users.filter((user) => user.id !== id)];
    setUsers(newSet);
  };
  const addToFavorite = (id) => {
    const index = users.findIndex((user) => user.id === id);
    if (index > -1) {
      let newSet = [
        ...users.map((user) =>
          user.id !== id ? user : { ...user, isFav: !user.isFav }
        ),
      ];
      console.log(newSet);
      setUsers(newSet);
    }
  };

  return (
    <Container>
      <Row>
        {USERLIST.length > 0 &&
          users?.map((user) => (
            <Col md="3" key={user.id}>
              <ProfileCard
                user={user}
                deleteUser={deleteUser}
                addToFavorite={addToFavorite}
              />
            </Col>
          ))}
      </Row>
    </Container>
  );
}

export default App;
